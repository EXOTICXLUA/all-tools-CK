<div align="center"><h1>ZTweaks</h1>
<h4>・Unleash Your FPS・<h4>
<img src="https://user-images.githubusercontent.com/108175829/236144303-311ea628-4d1d-4215-8cd3-410f56a95995.png" width="650" height="350">
<p align="center"><a href="https://discord.gg/MKtBtrjkyn" target="_blank">if you need help join discord server</a></p>
</div>
<hr>

## 💥Features:
 **Our utility has:**
* Removing debloat apps from Microsoft Store.
* Optimizes WiFi and Ethernet for lowest ping and packet loss.
* PC Cleaner which cleans the registry and junk files from your computer.
* DNS optimization for lower ping.
* Update-System if needed you can update ZTweaks with one click.
* Disables unneeded Windows services.
* Disables Windows Telementry.
* Resets the network card and drivers and fixes the large ping and packet loss.
* Desktop Window Manager (DWM) Tweaks, Which reduces CPU usage.
* Ping Reducer, Which reduces ping and packet instability.
* Sets the settings in the control panel to the best it can.
* Takes up little disk space.
* Sets games to high priority.
* Optimizes keyboard and mouse input latency to the lowest possible way.
* It has the ability to perform a Windows Restore Point with a single click.

**More coming soon!**

## 💨Compatibility:
* ZTweaks can only run on Windows 10 and Windows 11.
* Custom Windows (Tweaked for gaming).
